import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ownaproperty',
  templateUrl: './ownaproperty.component.html',
  styleUrls: ['./ownaproperty.component.css']
})
export class OwnapropertyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
