import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myproperties',
  templateUrl: './myproperties.component.html',
  styleUrls: ['./myproperties.component.css']
})
export class MypropertiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
