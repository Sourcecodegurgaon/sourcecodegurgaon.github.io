import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellermatches',
  templateUrl: './sellermatches.component.html',
  styleUrls: ['./sellermatches.component.css']
})
export class SellermatchesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
