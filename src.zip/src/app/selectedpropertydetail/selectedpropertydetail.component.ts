import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selectedpropertydetail',
  templateUrl: './selectedpropertydetail.component.html',
  styleUrls: ['./selectedpropertydetail.component.css']
})
export class SelectedpropertydetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
