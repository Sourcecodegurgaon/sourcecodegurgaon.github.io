import { Component, OnInit } from '@angular/core';
import { AuthService } from "../auth.service";


import { AngularFireAuth } from "@angular/fire/auth";
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';

import * as firebase from 'firebase';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  isLoggedIn: Boolean = true
  userData: any; // Save logged in user data
  boolean: boolean;
  private _user: firebase.User;
  public get user(): firebase.User {
    return this._user;
  }
  public set user(value: firebase.User) {
    this._user = value;
  }
  constructor(public authService: AuthService,
    public afs: AngularFirestore,   // Inject Firestore service
    public afAuth: AngularFireAuth,
  
    ) { }

  ngOnInit() {
    this.afAuth.authState.subscribe(user => {
      if (user) {
        this.userData = user;
        localStorage.setItem('user', JSON.stringify(this.userData));
        JSON.parse(localStorage.getItem('user'));
        this.LoggedIn();
      } else {
        localStorage.setItem('user', null);
        JSON.parse(localStorage.getItem('user'));
         this.LoggedOut();
      }
    })
  
  }


  private LoggedIn() {
    this.isLoggedIn = true
  }
  private LoggedOut() {
    this.isLoggedIn = false
  }
}
