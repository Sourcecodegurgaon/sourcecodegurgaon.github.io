import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectedpropertydetailComponent } from './selectedpropertydetail.component';

describe('SelectedpropertydetailComponent', () => {
  let component: SelectedpropertydetailComponent;
  let fixture: ComponentFixture<SelectedpropertydetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectedpropertydetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectedpropertydetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
