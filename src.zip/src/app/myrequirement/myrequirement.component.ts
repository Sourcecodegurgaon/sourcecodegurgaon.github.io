import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myrequirement',
  templateUrl: './myrequirement.component.html',
  styleUrls: ['./myrequirement.component.css']
})
export class MyrequirementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
