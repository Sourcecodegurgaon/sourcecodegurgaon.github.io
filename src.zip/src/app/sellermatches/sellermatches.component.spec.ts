import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellermatchesComponent } from './sellermatches.component';

describe('SellermatchesComponent', () => {
  let component: SellermatchesComponent;
  let fixture: ComponentFixture<SellermatchesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellermatchesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellermatchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
