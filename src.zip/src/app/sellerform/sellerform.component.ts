import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellerform',
  templateUrl: './sellerform.component.html',
  styleUrls: ['./sellerform.component.css']
})
export class SellerformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
