import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyerdetails',
  templateUrl: './buyerdetails.component.html',
  styleUrls: ['./buyerdetails.component.css']
})
export class BuyerdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
