import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequirementdetailsComponent } from './requirementdetails.component';

describe('RequirementdetailsComponent', () => {
  let component: RequirementdetailsComponent;
  let fixture: ComponentFixture<RequirementdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequirementdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequirementdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
