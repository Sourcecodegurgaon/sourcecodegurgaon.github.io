import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OwnapropertyComponent } from './ownaproperty.component';

describe('OwnapropertyComponent', () => {
  let component: OwnapropertyComponent;
  let fixture: ComponentFixture<OwnapropertyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OwnapropertyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OwnapropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
