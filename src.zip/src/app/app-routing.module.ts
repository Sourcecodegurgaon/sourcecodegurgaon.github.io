import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OwnapropertyComponent } from './ownaproperty/ownaproperty.component';
import { HomeComponent } from './home/home.component';
import { FormsComponent } from './forms/forms.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { MatchesComponent } from './matches/matches.component';
import { PropertydetailsComponent } from './propertydetails/propertydetails.component';
import { SellerformComponent } from './sellerform/sellerform.component';
import { SellermatchesComponent } from './sellermatches/sellermatches.component';
import { BuyerdetailsComponent } from './buyerdetails/buyerdetails.component';
import { ProfileComponent } from './profile/profile.component';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { MypropertiesComponent } from './myproperties/myproperties.component';
import { SelectedpropertydetailComponent } from './selectedpropertydetail/selectedpropertydetail.component';
import { MyrequirementComponent } from './myrequirement/myrequirement.component';
import { RequirementdetailsComponent } from './requirementdetails/requirementdetails.component';
import { PrefrencesComponent } from './prefrences/prefrences.component';
import { ChatsComponent } from './chats/chats.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { VerifyEmailComponent } from './components/verify-email/verify-email.component';
import { AuthGuard } from "./shared/guard/auth.guard";
import { SecureInnerPagesGuard } from "./shared/guard/secure-inner-pages.guard";




const routes: Routes = [
  {path:'ownaproperty' , component:OwnapropertyComponent },
 {path:'',component:HomeComponent},
 {path:'forms',component:FormsComponent} ,
 {path:'confirmation',component:ConfirmationComponent},
 {path:'matches',component:MatchesComponent},
 {path:'propertydetails',component:PropertydetailsComponent},
 {path:'sellerform',component:SellerformComponent},
 {path:'sellermatches',component:SellermatchesComponent},
 {path:'buyerdetails',component:BuyerdetailsComponent},
 {path:'profile',component:ProfileComponent},
 {path:'editprofile',component:EditprofileComponent},
 {path:'myproperties',component:MypropertiesComponent},
 {path:'selectedpropertydetail', component:SelectedpropertydetailComponent},
 {path:'myrequirement',component:MyrequirementComponent},
 {path:'requirementdetails',component:RequirementdetailsComponent},
 {path:'prefrences',component:PrefrencesComponent},
 {path:'chats',component:ChatsComponent},
 { path: 'sign-in', component:SignUpComponent },
 { path: 'register-user', component: SignUpComponent },
 { path: 'dashboard', component:DashboardComponent},
 { path: 'forgot-password', component:ForgotPasswordComponent },
 { path: 'verify-email-address', component: VerifyEmailComponent }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
