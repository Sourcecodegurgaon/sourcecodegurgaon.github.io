import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requirementdetails',
  templateUrl: './requirementdetails.component.html',
  styleUrls: ['./requirementdetails.component.css']
})
export class RequirementdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
